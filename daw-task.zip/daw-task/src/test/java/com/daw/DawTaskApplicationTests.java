package com.daw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DawTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
